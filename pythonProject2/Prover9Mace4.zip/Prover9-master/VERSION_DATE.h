#define PROGRAM_DATE     "November 2017"
#define PROGRAM_VERSION  "2017-11A (CIIRC)"
