#include "auto.h"

/* Private definitions and types */


